const usuarioLogado = pegarUsuarioLogado()
var saldo = usuarioLogado.conta.saldo
const bancoAtual = pegarInformacoesDoBanco()
document.getElementById("nome").innerHTML = usuarioLogado.conta.usuario.nome
document.getElementById("saldo").innerHTML = saldo


var valorDigitado
var agenciaDigitada
var agenciaEncontrada
var contaDigitada
var contaEncontrada
var errosList = []

function validarSaldo() {
  valorDigitado = document.getElementById("valor").value
  if (valorDigitado > saldo) {
    document.getElementById("valorError").innerHTML = "Saldo insuficiente, tente novamente"
    errosList.push("saldo")
  } else {
    errosList = errosList.filter(erro => erro != "saldo")
    document.getElementById("valorError").innerHTML = ""
  }
}

function validarAgencia() {
  agenciaDigitada = document.getElementById("agencia").value
  agenciaEncontrada = bancoAtual.agencias.find(agencia => agencia.numero == agenciaDigitada)
  if (agenciaEncontrada == null) {
    document.getElementById("agenciaError").innerHTML = "Agencia não encontrada, tente novamente"
    errosList.push("agencia")
  } else {
    errosList = errosList.filter(erro => erro != "agencia")
    document.getElementById("agenciaError").innerHTML = ""
  }
}

function validarConta() {
  contaDigitada = document.getElementById("conta").value
  contaEncontrada = agenciaEncontrada?.contas.find(conta => contaDigitada == conta.numero)
  if (contaEncontrada == null) {
    document.getElementById("contaError").innerHTML = "Conta não encontrada, tente novamente"
    errosList.push("conta")
  } else {
    errosList = errosList.filter(erro => erro != "conta")
    document.getElementById("contaError").innerHTML = ""
  }
}

function transferir() {

}