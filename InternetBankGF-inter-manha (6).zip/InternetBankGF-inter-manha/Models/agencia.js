class Agencia{
  constructor(numero, contas){
    this.numero = numero
    this.contas = contas
  }
}