class Banco{
  constructor(nome, agencias){
    this.nome = nome
    this.agencias = agencias
  }
}