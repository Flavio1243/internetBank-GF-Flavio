class Conta{
  constructor(numero, senha, saldo, usuario){
    this.numero = numero
    this.senha = senha
    this.saldo = saldo
    this.usuario = usuario
  }
}