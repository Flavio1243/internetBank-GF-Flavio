class Usuario {
  constructor(nome, cpf, email, idade){
    this.nome = nome
    this.cpf = cpf
    this.email = email
    this.idade = idade
  }
}